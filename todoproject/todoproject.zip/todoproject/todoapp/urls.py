from .import views
from django.urls import path, include

urlpatterns = [

    path('',views.add,name='home.html'),
    path('delete/<int:taskid>/',views.delete,name='delete'),
    path('update/<int:id>/', views.update, name='update')
]